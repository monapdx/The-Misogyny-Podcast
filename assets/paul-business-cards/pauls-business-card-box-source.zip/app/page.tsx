"use client";
import { useState } from "react";

type Card={id:string;short:string;run:string;title:string;role:string;detail:string;printed:number;left:number;flaw:string;color:string;ink:string;rotation:number};
const cards:Card[]=[
 {id:"v1",short:"V1",run:"FIRST PRINTING",title:"PAUL EMERSON",role:"EXECUTIVE PRODUCER",detail:"THE MISOGYNY PODCAST",printed:3000,left:2847,flaw:"No phone number, email address, URL, or other method of contact.",color:"#f7f1df",ink:"#17140f",rotation:-3},
 {id:"v2",short:"V2",run:"CONTACT EDITION",title:"PAUL EMERSON",role:"EXECUTIVE PRODUCER",detail:"paul@misogynypodcas.com",printed:1000,left:913,flaw:"The podcast domain is missing the final “t.” Paul approved the proof anyway.",color:"#f5df34",ink:"#17140f",rotation:2},
 {id:"v3",short:"V3",run:"PREMIUM BLACK",title:"PAUL EMERSON",role:"EXECUTIVE PRODUCER & CO-FOUNDER",detail:"THE MISOGYNY PODCAST",printed:500,left:462,flaw:"Glossy black stock. Fingerprints instantly. Derek was not consulted about “Co-Founder.”",color:"#171717",ink:"#f8efcf",rotation:-1},
 {id:"v4",short:"V4",run:"QR RELAUNCH",title:"PAUL EMERSON",role:"EXECUTIVE PRODUCER",detail:"SCAN TO LISTEN  ▣",printed:750,left:621,flaw:"The QR code links to the printer’s sample restaurant menu.",color:"#ff6838",ink:"#21130d",rotation:4},
 {id:"v5",short:"V5",run:"DEREK-APPROVED",title:"PAUL EMERSON",role:"PRODUCTION ASSOCIATE",detail:"A PODCAST BY DEREK VALE",printed:250,left:48,flaw:"Technically accurate. Paul hates this version and gives it away first.",color:"#d8d1bf",ink:"#211f1a",rotation:-4},
 {id:"v6",short:"V6",run:"CURRENT CARD",title:"PAUL EMERSON",role:"EXECUTIVE PRODUCER",detail:"MISOGYNYPODCAST.COM  ·  @PAULEMERSON",printed:500,left:497,flaw:"Everything is correct. Paul has become emotionally attached to the older mistakes.",color:"#a8ff3e",ink:"#10220a",rotation:1},
];
const loose=[0,1,0,3,2,4,1,0,5,3,0,2,4,1,0,5,3,2];
export default function Home(){
 const [selected,setSelected]=useState(cards[0]); const [pulled,setPulled]=useState(false);
 const choose=(card:Card)=>{setPulled(false);setTimeout(()=>{setSelected(card);setPulled(true)},80)};
 const used=selected.printed-selected.left,remaining=Math.round(selected.left/selected.printed*100);
 return <main>
  <header className="masthead"><div><p className="eyebrow">PROPERTY OF PAUL EMERSON</p><h1>The Business Card Box</h1></div><p className="header-note">Six print runs. One preventable problem after another.</p></header>
  <section className="desk" aria-label="Paul's business card archive"><div className="coffee-ring"/><div className="scribble">DON’T THROW<br/>ANY OF THESE OUT!</div>
   <div className="box-wrap"><div className="box-lid"><span>BUSINESS CARDS</span><small>mixed / important</small></div><div className="card-box"><div className="box-back"/>
    {loose.map((n,i)=>{const c=cards[n];return <button key={`${c.id}-${i}`} className="loose-card" style={{"--card-color":c.color,"--card-ink":c.ink,"--r":`${c.rotation+((i%3)-1)*1.2}deg`,"--x":`${7+(i%6)*14+(i%2)*1.5}%`,"--y":`${10+Math.floor(i/6)*23+(i%4)*1.3}%`,"--z":i} as React.CSSProperties} onClick={()=>choose(c)} aria-label={`Show ${c.run}`}><span>{c.title}</span><small>{c.role}</small></button>})}
    <div className="divider one">OLD / BAD</div><div className="divider two">CURRENT?</div><div className="box-front"><b>PAUL’S CARDS</b><span>DO NOT ORGANIZE</span></div>
   </div></div>
   <aside className="inspection"><p className="inspection-label">SELECTED CARD · {selected.short}</p>
    <div className={`hero-card ${pulled?"pulled":""}`} style={{"--hero-color":selected.color,"--hero-ink":selected.ink} as React.CSSProperties}><div className="card-grain"/><p className="hero-name">{selected.title}</p><p className="hero-role">{selected.role}</p><p className="hero-detail">{selected.detail}</p></div>
    <div className="stats"><div><span>PRINT RUN</span><strong>{selected.printed.toLocaleString()}</strong></div><div><span>GIVEN AWAY</span><strong>{used.toLocaleString()}</strong></div><div className="inventory"><span>STILL IN THE BOX</span><strong>{selected.left.toLocaleString()}</strong></div></div>
    <div className="meter"><i style={{width:`${remaining}%`}}/></div><p className="remaining-copy">{remaining}% of this regrettable investment remains.</p>
    <div className="incident"><span>KNOWN ISSUE</span><p>{selected.flaw}</p></div>
    <nav className="versions" aria-label="Card versions">{cards.map(c=><button key={c.id} onClick={()=>choose(c)} className={selected.id===c.id?"active":""}><b>{c.short}</b><span>{c.run}</span></button>)}</nav>
   </aside>
  </section><footer><span>THE MISOGYNY PODCAST ARCHIVES</span><span>Inventory last counted by Paul. Numbers should not be trusted.</span></footer>
 </main>
}
