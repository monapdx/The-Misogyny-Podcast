# Installation

Copy these three files into the repository, preserving their paths:

- `index.html`
- `scripts/update_episode_archives.py`
- `.github/workflows/update-episode-archives.yml`

Then delete the superseded files:

- `scripts/update_episode_table.py`
- `.github/workflows/update-episode-table.yml`

Every `episodes/episode-N.md` file must begin with frontmatter containing at least a title. Category is optional and defaults to `broadcast`:

```yaml
---
title: "WOMEN IN THE MILITARY"
category: broadcast
tags: [military, government]
---
```

Push the installation commit. The workflow can then be run manually from the Actions tab; future changes inside `episodes/` trigger it automatically.
